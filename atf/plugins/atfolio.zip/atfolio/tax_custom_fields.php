<?php
/**
 * Created by PhpStorm.
 * User: eugen
 * Date: 2/17/15
 * Time: 3:50 PM
 */

add_action( 'atfolio_clients_edit_form_fields', 'client_extra_tax_fields');
add_action( 'edited_atfolio_clients', 'save_extra_taxonomy_fields', 10, 2);



function client_extra_tax_fields($tag) {
    //check for existing taxonomy meta for term ID


    wp_enqueue_script(
        'atf-options-field-upload-js',
        plugin_dir_url( __FILE__ ) . 'assets/field_upload.js',
        array('jquery'),
        time(),
        true
    );
    wp_enqueue_media();
    wp_localize_script('atf-options-field-upload-js', 'redux_upload', array('url' => plugin_dir_url( __FILE__ ) . 'assets/blank.png'));



    $t_id = $tag->term_id;
    $term_meta = get_option( "taxonomy_$t_id");




    $result = '<div class="uploader">';
    $result .= '<input type="hidden" id="metaimg" name="term_meta[img]" value="'.$term_meta['img'].'" class="" />';
    $result .= '<img class="atf-options-upload-screenshot" id="screenshot-metaimg" src="'.$term_meta['img'].'" />';
    if($term_meta['img'] == '') {$remove = ' style="display:none;"'; $upload = ''; } else {$remove = ''; $upload = ' style="display:none;"'; }
    $result .= ' <a data-update="Select File" data-choose="Choose a File" href="javascript:void(0);"class="atf-options-upload button-secondary"' . $upload . ' rel-id="metaimg">' . __('Upload', 'atf') . '</a>';
    $result .= ' <a href="javascript:void(0);" class="atf-options-upload-remove"' . $remove . ' rel-id="metaimg">' . __('Remove Upload', 'atf') . '</a>';
    $result .= '</div>';



    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="cat_Image_url"><?php _e('Client logo'); ?></label></th>
        <td>

            <?php echo $result; ?><br />
            <span class="description"><?php _e('Image for Term: use full url with '); ?></span>
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="extra1"><?php _e('Client web-site url'); ?></label></th>
        <td>
            <input type="text" name="term_meta[websiteurl]" id="term_meta[extra1]" size="25" style="width:60%;" value="<?php echo $term_meta['websiteurl'] ? $term_meta['websiteurl'] : ''; ?>"><br />
            <span class="description"><?php _e('extra field'); ?></span>
        </td>
    </tr>
<?php
}
function get_extra_tax_field ($tax_id) {
    return get_option( "taxonomy_$tax_id");
}

// save extra taxonomy fields callback function
function save_extra_taxonomy_fields( $term_id ) {

    if ( isset( $_POST['term_meta'] ) ) {

        $t_id = $term_id;
        $term_meta = get_option( "taxonomy_$t_id");
        $cat_keys = array_keys($_POST['term_meta']);
        foreach ($cat_keys as $key){
            if (isset($_POST['term_meta'][$key])){
                $term_meta[$key] = $_POST['term_meta'][$key];
            }
        }
        //save the option array
        update_option( "taxonomy_$t_id", $term_meta );
    }
}