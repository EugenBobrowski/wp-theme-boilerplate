<?php
/**
 * Created by PhpStorm.
 * User: eugen
 * Date: 2/17/15
 * Time: 1:26 AM
 */

add_shortcode('atfolio', 'atfolio_shortcode');

function atfolio_shortcode ($attr) {

    // The Query
    $the_query = new WP_Query( array(
        'post_type' => 'atfolio',
        'posts_per_page' => (!empty($attr['count'])) ? $attr['count'] : 12 ,
    ) );

    // The Loop
    if ( $the_query->have_posts() ) {
        $index_no = $the_query->found_posts - $the_query->post_count;
        if ($index_no == 0) $index_no = 59;
        echo '<div class="row folio-plate">';
        while ( $the_query->have_posts() ) {
            $the_query->the_post();
            global $post;

            ?>
            <div class="col-lg-2 col-md-3 col-sm-3 col-xs-6 folio-item">
                <?php $blurImg = get_atf_post_thumbnail(20,20); ?>
                <?php echo '<img class="blur" src="'.$blurImg.'" />'; ?>
                <?php echo '<img class="lazy" data-original="'.get_atf_post_thumbnail(390,390).'" src="'.$blurImg.'" />'; ?>
                <article class="item-container">
                    <header>
                        <div class="project-num">
                            <?php $index_no++; echo $index_no;  ?>
                        </div>
                        <div class="title">
                            <a href="<?php echo get_permalink(); ?>" class="">
                                <?php

                                if (!empty($meta['shortin'])) {
                                    echo $meta['shortin'];
                                } else {
                                    echo substr(get_the_title(), 0, 2);
                                }


                                ?></a>
                            <div class="name">
                                <?php echo get_the_title(); ?>
                            </div>
                        </div>




                        <div class="location-folio">
                            <span class="glyphicon glyphicon-map-marker"></span>
                            <?php foreach(wp_get_post_terms($post->ID, 'atfolio_locations') as $location) {
                                echo '<a href="'.get_term_link($location->term_id, 'atfolio_locations').'">'.$location->name.'</a>';
                            } ?>
                        </div>
                    </header>
                </article>
            </div>



        <?php

        }
        echo '</div>';
    } else {
        // no posts found
    }
    /* Restore original Post Data */
    wp_reset_postdata();

}